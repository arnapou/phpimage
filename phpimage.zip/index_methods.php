<?php
include('index_header.php');
?>
<fieldset><legend>Methods Summary</legend>
	<?php menufiles('methods'); ?>
</fieldset>
<fieldset><legend>Methods</legend> 
	<?php showfiles('methods'); ?> 
</fieldset>
<?php
include('index_footer.php');
?>