<?php
include('index_header.php');
?>
<fieldset><legend>Properties Summary</legend>
	<?php menufiles('properties'); ?>
</fieldset>
<fieldset><legend>Properties</legend> 
	<?php showfiles('properties'); ?> 
</fieldset>
<?php
include('index_footer.php');
?>