<?php
require('../class.PHPImage.php');
$image = new PHPImage('php.gif');
$image->effect('emboss');
$image->format = 'png';
$image->display();
?>