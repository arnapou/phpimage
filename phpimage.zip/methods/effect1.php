<?php
require('../class.PHPImage.php');
$image = new PHPImage('php.gif');
$image->effect('edgedetect');
$image->format = 'png';
$image->display();
?>