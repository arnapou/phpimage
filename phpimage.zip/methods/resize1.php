<?php
require('../class.PHPImage.php');
$image = new PHPImage('php.gif');
$image->resize(75, 75);
$image->format = 'png';
$image->display();
?>